public class BigImgInfo
{
	public short id;

	public short ver;

	public short follow;

	public sbyte[] data;

	public Image img;
}
