public class BoardInfo
{
	public sbyte boardID;

	public sbyte nPlayer;

	public sbyte maxPlayer;

	public bool isPass;

	public bool isPlaying;

	public int money;

	public string strMoney;
}
