public abstract class Dialog : AvMain
{
	public abstract void show();

	public virtual void init(int h)
	{
	}
}
