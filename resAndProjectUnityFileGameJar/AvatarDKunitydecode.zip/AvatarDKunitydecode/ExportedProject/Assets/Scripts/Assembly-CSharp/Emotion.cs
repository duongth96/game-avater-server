public class Emotion
{
	public sbyte type;

	public short id;

	public short time;
}
