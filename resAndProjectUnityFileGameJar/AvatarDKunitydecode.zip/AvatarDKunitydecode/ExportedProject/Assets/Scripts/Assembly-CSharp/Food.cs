public class Food
{
	public short ID;

	public short productID;

	public short cookTime;

	public string text;

	public short[] material;

	public short[] numberMaterial;
}
