public class Frame
{
	public sbyte[] idImg;

	public short[] dx;

	public short[] dy;
}
