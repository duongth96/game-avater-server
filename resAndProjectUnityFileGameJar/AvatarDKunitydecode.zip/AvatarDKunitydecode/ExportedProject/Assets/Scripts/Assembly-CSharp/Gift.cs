public class Gift
{
	public short idPart;

	public sbyte type;

	public int xu;

	public int x;

	public int y;

	public int xp;

	public int luong;

	public string expire;
}
