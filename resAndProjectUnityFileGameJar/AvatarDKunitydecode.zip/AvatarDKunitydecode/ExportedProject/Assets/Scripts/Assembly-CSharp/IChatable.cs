public interface IChatable
{
	void onChatFromMe(string text);
}
