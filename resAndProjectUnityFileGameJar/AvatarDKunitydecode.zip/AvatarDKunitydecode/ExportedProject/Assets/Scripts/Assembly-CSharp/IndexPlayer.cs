public class IndexPlayer
{
	public sbyte friendly;

	public sbyte crazy;

	public sbyte happy;

	public sbyte hunger;

	public sbyte stylish;

	public sbyte percentLv;

	public sbyte hungerPet;

	public short level;
}
