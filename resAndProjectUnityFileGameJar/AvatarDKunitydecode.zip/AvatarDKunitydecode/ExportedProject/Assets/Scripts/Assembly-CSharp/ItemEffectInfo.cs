public class ItemEffectInfo
{
	public short IDAction;

	public short IDIcon;

	public string name;

	public int money;

	public sbyte typeMoney;
}
