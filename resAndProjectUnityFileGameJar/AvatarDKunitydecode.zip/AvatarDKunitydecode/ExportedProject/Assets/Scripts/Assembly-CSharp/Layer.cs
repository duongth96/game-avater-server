public class Layer
{
	public virtual void update()
	{
	}

	public virtual void paint(MyGraphics g, int x, int y)
	{
	}
}
