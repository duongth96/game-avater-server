public class MapItemType
{
	public short idType;

	public short imgID;

	public short iconID;

	public short priceLuong;

	public short dx;

	public short dy;

	public string name;

	public string des;

	public int priceXu;

	public sbyte buy;

	public sbyte dir;

	public MyVector listNotTrans;
}
