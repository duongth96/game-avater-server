public class MoneyInfo
{
	public string info;

	public string strID;

	public string smsContent;

	public string smsTo;
}
