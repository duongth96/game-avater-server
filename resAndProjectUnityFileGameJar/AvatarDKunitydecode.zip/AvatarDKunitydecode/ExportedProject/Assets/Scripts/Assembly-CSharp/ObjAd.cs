public class ObjAd
{
	public int id;

	public int typeShop;

	public string title;

	public string text;

	public string url;

	public string sms;

	public string to;

	public MyVector listPoint;
}
