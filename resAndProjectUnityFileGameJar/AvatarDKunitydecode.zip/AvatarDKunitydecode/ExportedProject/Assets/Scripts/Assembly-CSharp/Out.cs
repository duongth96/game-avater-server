using System;

public class Out
{
	public static void println(string s)
	{
	}

	public static void logError(Exception e)
	{
	}

	public static void logError(Exception e, string path)
	{
	}
}
