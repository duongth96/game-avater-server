public class PartSmall : Part
{
}
