public class SeriPart
{
	public short idPart;

	public sbyte time;

	public string expireString;

	public SeriPart()
	{
	}

	public SeriPart(short idP)
	{
		idPart = idP;
	}
}
