public class T
{
	public static string pleaseWait;

	public static string menu;

	public static string close;

	public static string agree;

	public static string updateList;

	public static string playNow;

	public static string strongest;

	public static string richest;

	public static string ready;

	public static string noReady;

	public static string start;

	public static string yes;

	public static string no;

	public static string viewMessage;

	public static string setMoney;

	public static string setNumPlayers;

	public static string setPass;

	public static string exitBoard;

	public static string kick;

	public static string continuee;

	public static string exit;

	public static string addFriend;

	public static string OK;

	public static string fire;

	public static string skip;

	public static string xu;

	public static string gold;

	public static string gameDraw;

	public static string sapBaiXong;

	public static string numTienCuoc;

	public static string youAreKicked;

	public static string setPassed;

	public static string opponentQuit;

	public static string forceFinish;

	public static string sendMessage;

	public static string connecting;

	public static string logging;

	public static string selectt;

	public static string doYouWantExit2;

	public static string banChiCo;

	public static string setMaxMoney;

	public static string doYouWantSkip;

	public static string youMustFire3Bich;

	public static string notSameOrSmaller;

	public static string dola;

	public static string firstFire;

	public static string room;

	public static string goad;

	public static string youFirstFire;

	public static string enemyFirstFire;

	public static string sixPointNoWin;

	public static string block2NoWin;

	public static string pw;

	public static string connectFail;

	public static string cannotMove;

	public static string chieuTuong;

	public static string buy;

	public static string friend;

	public static string option;

	public static string eat;

	public static string gett;

	public static string haPhom;

	public static string canYouOnceOnly;

	public static string yetSellectCard;

	public static string ifFireBreakPhom;

	public static string waitToCurrent;

	public static string notSamePhom;

	public static string youSelect;

	public static string notPhom;

	public static string viewMyInfo;

	public static string goToBoard;

	public static string moneyStr;

	public static string ifPassword;

	public static string joinA = "vao";

	public static string QuytA = "thoat";

	public static string pCard = "/card";

	public static string pImg = "/img";

	public static string pFont = "/font";

	public static string pBackG = "/bg";

	public static string pHome = "/home";

	public static string pFarm = "/farm";

	public static string pEffect = "/effect";

	public static string pMain = "/main";

	public static string pData = "/data";

	public static string pHomeDe = "/homeDe";

	public static string pDialLucky = "/dialLucky";

	public static string number;

	public static string priceStr;

	public static string nameStr;

	public static string pant;

	public static string cloth;

	public static string hair;

	public static string eye;

	public static string doYouWantBuy;

	public static string selectMoney;

	public static string link = "http://";

	public static string replaceNam = "@username";

	public static string tkChinh;

	public static string tkFarm;

	public static string inCome;

	public static string getFarmData;

	public static string getData;

	public static string storePro;

	public static string won;

	public static string disConnect;

	public static string win;

	public static string lose;

	public static string draw;

	public static string give;

	public static string youAreBittenByDog;

	public static string opponentAreNotReady;

	public static string exited;

	public static string complete;

	public static string areaIsFull;

	public static string area;

	public static string cardToMiss;

	public static string upTwoCard;

	public static string chat;

	public static string del;

	public static string beingOn;

	public static string StoreEmtpy;

	public static string watering;

	public static string land;

	public static string empty;

	public static string feeding;

	public static string sell;

	public static string notTooGreedy;

	public static string youWantBreakTree;

	public static string diarrhea;

	public static string flu;

	public static string hunger;

	public static string tire;

	public static string milk;

	public static string egg;

	public static string notOnFarm;

	public static string youWantBuyPro;

	public static string h;

	public static string seed;

	public static string item;

	public static string feedFor;

	public static string notOnFarmOther;

	public static string StoreSeed;

	public static string youAreBittenByDogByHound;

	public static string foodForEmpty;

	public static string moneySellPro;

	public static string mySeft;

	public static string next;

	public static string remem;

	public static string fogetPass;

	public static string nameAcc;

	public static string FAQs;

	public static string updateGame;

	public static string support;

	public static string delRMS;

	public static string alreadyDelRMS;

	public static string youUseNumRegGetpass;

	public static string areYouUseNumReg;

	public static string removee;

	public static string disagree;

	public static string viewRule;

	public static string areYouAgreeRule;

	public static string acc;

	public static string pass;

	public static string selectRegion;

	public static string rememPass;

	public static string eventt;

	public static string giveGift;

	public static string hit;

	public static string kiss;

	public static string viewInfo;

	public static string privateMsg;

	public static string action;

	public static string feel;

	public static string exchange;

	public static string giveGiftFlower;

	public static string with;

	public static string refused;

	public static string noQ;

	public static string index;

	public static string doo;

	public static string detail;

	public static string have;

	public static string loadMoney;

	public static string msgNew;

	public static string closeTab;

	public static string beginChat;

	public static string success;

	public static string createChar;

	public static string face;

	public static string createCharFail;

	public static string lvNotChange;

	public static string cap;

	public static string salonBeauty;

	public static string lvUse;

	public static string cancel;

	public static string canHarvest;

	public static string hasRob;

	public static string container;

	public static string doYouWantDel;

	public static string trans;

	public static string doBen;

	public static string use;

	public static string sentMsg;

	public static string canNotSendMsg;

	public static string doYouWantExit;

	public static string info;

	public static string changePass;

	public static string finish;

	public static string toss;

	public static string bite;

	public static string miss;

	public static string numberFish;

	public static string achieve;

	public static string view;

	public static string enterAgain;

	public static string doYouWantToTrade;

	public static string giveGame;

	public static string sentToFriend;

	public static string phoneNumber;

	public static string youCanSelectFromMenu;

	public static string otherGame;

	public static string doYouWantUpgradeCoffer;

	public static string doYouWantExitIntoRegion;

	public static string sendTo;

	public static string day;

	public static string theft;

	public static string food;

	public static string dial;

	public static string doYouWantDial;

	public static string forever;

	public static string doYouWanBuyPrice;

	public static string sett;

	public static string homeRepait;

	public static string buyItem;

	public static string latGach;

	public static string sellItem;

	public static string noItem;

	public static string move;

	public static string rota;

	public static string doWantSellItem;

	public static string noPlaceItemHere;

	public static string haveItem;

	public static string setTuong;

	public static string noFriend;

	public static string goHome;

	public static string joinFrHome;

	public static string cho;

	public static string dunation;

	public static string inviteMyHouse;

	public static string upgradeChest;

	public static string outHouse;

	public static string cityIsOffLine;

	public static string chay;

	public static string u;

	public static string denU;

	public static string youAre;

	public static string youAreInvite;

	public static string doYouWant;

	public static string basket;

	public static string canNotConnect;

	public static string constructing;

	public static string roomList;

	public static string roomName;

	public static string emptyRoom;

	public static string register;

	public static string login;

	public static string selectLanguage;

	public static string uNeedExitGame;

	public static string Dial;

	public static string enterPassReferral;

	public static string registerSuccess;

	public static string cannotRegister;

	public static string gettingPrice;

	public static string sms;

	public static string sendSmgFinish;

	public static string notSendSmg;

	public static string email;

	public static string back;

	public static string startTa;

	public static string selectAgain;

	public static string ta;

	public static string wearing;

	public static string levelRequest;

	public static string map;

	public static string tiengViet;

	public static string tiengAnh;

	public static string catdo;

	public static string removeFriend;

	public static string uRemoveFriend;

	public static string viewContinue;

	public static string roomOn;

	public static string enterNumber;

	public static string chooseAnotherCity;

	public static string top;

	public static string quay;

	public static string game;

	public static string doUWantCancel;

	public static string QuickCooking;

	public static string QuickUpgrade;

	public static string update;

	public static string cooking;

	public static string gift;

	public static string listNameGame;

	public static string datCuoc;

	public static string other;

	public static string usureStop;

	public static string tkNew;

	public static string wedding;

	public static string doYouWantTransMoney;

	public static string doYouWantAddFr;

	public static string[] numPlayer;

	public static string[] nameCasino;

	public static string[] nameCasino1;

	public static string[] nameCasinoOngame;

	public static string[] level;

	public static string[] fallFlower;

	public static string[] enterCard;

	public static string[] nameReg;

	public static string[] lister;

	public static string[] chatHeo;

	public static string[] enterPass;

	public static string[] trasContainter;

	public static string[] youWantFeeding;

	public static string[] gender;

	public static string[] myIndex;

	public static string[] strName;

	public static string[] strTransMoney;

	public static string[] roomLevelText;

	public static string[] actionStr;

	public static string[] nameRegion;

	public static string[] nameMenuOn;

	public static string[] nameTab;

	public static string[] hd = new string[3] { "normal", "medium", "hd" };

	public static string[] cardTypeName;

	public static string[][] nameChangePass;

	public static string[][] name;

	public static string[][] loadCard;

	public static string notEnough;

	public static string salePrice;

	public static string material;

	public static string done;

	public static string time;

	public static string harvest;

	public static string cook;

	public static string[] mode = new string[2] { "medium", "hd" };

	public static string temp = "của chúng ta chốt danh sách thành";

	public T()
	{
		listNameGame = "Danh sách trò chơi";
		pleaseWait = "Xin chờ";
		menu = "Menu";
		close = "Đóng";
		agree = "Đồng ý";
		updateList = "Cập nhật";
		playNow = "Chơi nhanh";
		strongest = "Top cao thủ";
		richest = "Top đại gia";
		nameCasino = new string[4] { "Tiến Lên", "Phỏm", "Kim Cương", "Bầu Cua" };
		nameCasino1 = new string[3] { "Kim cương", "Bầu cua", "Ongame" };
		nameCasinoOngame = new string[2] { "Tiến lên", "Phỏm" };
		nameMenuOn = new string[5] { "Tiến Lên", "Phỏm", "Kim cương", "Bầu cua", "Chuyển tiền" };
		ready = "Sẵn sàng";
		noReady = "Ko s.sàng";
		start = "Bắt đầu";
		yes = "Có";
		no = "Không";
		viewMessage = "Tin nhắn";
		setMoney = "Đặt tiền cược";
		setNumPlayers = "Đặt số người";
		setPass = "Đặt mật khẩu";
		exitBoard = "Rời bàn";
		kick = "Đuổi";
		continuee = "Tiếp tục";
		exit = "Thoát";
		addFriend = "Kết bạn";
		OK = "OK";
		fire = "Đánh";
		skip = "Bỏ lượt";
		xu = "xu";
		gold = "lượng";
		gameDraw = "Ván hòa.";
		numPlayer = new string[3] { "2 người", "3 người", "4 người" };
		sapBaiXong = "Sắp bài xong";
		numTienCuoc = "Số tiền cược";
		youAreKicked = "Bạn bị đuổi.";
		setPassed = "Đã đặt mật khẩu.";
		opponentQuit = "Đối thủ thoát. Bạn thắng";
		forceFinish = "Tới trắng";
		sendMessage = "Nhắn tin";
		connecting = "Đang kết nối";
		logging = "Đang đăng nhập";
		selectt = "Chọn";
		doYouWantExit2 = "Bạn có muốn thoát?";
		banChiCo = "Bạn chỉ có ";
		setMaxMoney = ".";
		doYouWantSkip = "Bạn có chắc bỏ lượt?";
		youMustFire3Bich = "Bắt buột đánh 3 bích trước.";
		notSameOrSmaller = "Không cùng loại hoặc nhỏ hơn bài đang trên bàn.";
		dola = "$";
		firstFire = " đi trước.";
		room = "Phòng ";
		goad = "Tới ";
		youFirstFire = "Bạn đánh trước.";
		enemyFirstFire = "Đối thủ đánh trước.";
		level = new string[4] { "C.độ chính: ", "C.độ nông trại: ", "Cấp độ", "Cấp độ câu cá: " };
		sixPointNoWin = "6 quân không thắng";
		block2NoWin = "Chặn 2 đầu không thắng";
		pw = "Password";
		connectFail = "Kết nối thất bại. Bạn có muốn cập nhật lại danh sách Thành Phố.";
		cannotMove = "Nước này không đi được";
		chieuTuong = "Chiếu tướng";
		buy = "Mua";
		friend = "Bạn bè";
		option = "Cài đặt";
		eat = "ăn";
		gett = "Nhận";
		haPhom = "Hạ Phỏm";
		canYouOnceOnly = "Bạn chỉ được đánh một lá.";
		yetSellectCard = "Bạn chưa chọn bài.";
		ifFireBreakPhom = "Nếu đánh lá này bạn sẽ phá phỏm";
		waitToCurrent = "Chờ đến lượt.";
		notSamePhom = "Không đúng phỏm.";
		youSelect = "Bạn chọn quá nhiều bài.";
		notPhom = "Không phải là phỏm.";
		viewMyInfo = "Xem thành tích";
		goToBoard = "Đến bàn số..";
		moneyStr = "Tiền: ";
		ifPassword = "Password:";
		joinA = "Vào";
		QuytA = "Thoát";
		number = "Số lượng: ";
		priceStr = "Giá: ";
		nameStr = "Tên: ";
		pant = "Quần ";
		cloth = "Áo ";
		hair = "Tóc ";
		eye = "Mắt ";
		doYouWantBuy = "Bạn có muốn mua không?";
		actionStr = new string[4] { "Nhảy", "Nằm", "Ngồi bệt", "Quỳ" };
		selectMoney = "Bạn muốn mua bằng gì?";
		tkChinh = "TK Chính: ";
		tkFarm = "TK Nông trại: ";
		inCome = "Thu nhập: ";
		getFarmData = "Đang lấy dữ liệu nông trại...";
		getData = "Cập nhật dữ liệu..";
		storePro = "Kho hàng";
		roomLevelText = new string[4] { "Phòng sơ cấp", "Phòng trung cấp", "Phòng cao thủ", "Phòng thi đấu" };
		won = " đã chiến thắng";
		disConnect = "Mất kết nối";
		win = "Thắng";
		lose = "Thua";
		draw = "Hòa";
		give = "Bỏ cuộc";
		youAreBittenByDog = "Bạn bị chó cắn";
		opponentAreNotReady = "Đối thủ chưa sẵn sàng";
		exited = " đã thoát";
		name = new string[5][];
		name[0] = new string[3] { "hiện", "ẩn", "Tên" };
		name[1] = new string[3] { "hiện", "ẩn", "Chỉ đường" };
		name[2] = new string[3]
		{
			string.Empty,
			string.Empty,
			"âm thanh"
		};
		name[3] = new string[3] { "GPRS", "Wifi", "Kết nối" };
		name[4] = new string[3] { "Tiếng việt", "Tiếng Anh", "Ngôn ngữ" };
		complete = "Xong";
		areaIsFull = "Khu vực đã đầy.";
		area = "Khu vực ";
		cardToMiss = "Lá bài bạn đánh không có thực.";
		upTwoCard = "Năng ít nhất 2 lá để ăn.";
		chat = "Chat";
		del = "Xóa";
		nameRegion = new string[8] { "Khu nhà ở", "Khu sinh thái", "Sân bay", "Khu giải trí", "Khu mua sắm", "Công viên", "Khu ngoại ô", "Nông trại" };
		beingOn = "Đang vào ";
		StoreEmtpy = "Kho đã hết giống.";
		watering = "Tưới nước";
		land = "Làm đất";
		empty = "Đã hết ";
		feeding = "Cho ăn";
		sell = "Bán";
		notTooGreedy = "Đừng tham lam quá.";
		youWantBreakTree = "Bạn muốn phá cây đang có?";
		diarrhea = "Bị tiêu chảy";
		flu = "Bị cúm";
		hunger = "Đói bụng";
		tire = "Mệt quá";
		milk = "Sữa bò";
		egg = "Trứng gà";
		notOnFarm = "Không vào được nông trại.";
		youWantBuyPro = "Bạn có muốn bán nông sản?";
		h = " Giờ";
		seed = "Giống";
		item = "Vật Phẩm";
		feedFor = "Thức ăn cho ";
		notOnFarmOther = "Không thể vào.";
		StoreSeed = "Kho Giống";
		youAreBittenByDogByHound = "Bạn đã bị bắt.";
		foodForEmpty = "Hết thức ăn.";
		youWantFeeding = new string[3] { "Cho bò ăn?", "Cho heo ăn?", "Cho chó ăn?" };
		moneySellPro = "Tiền bán nông sản: ";
		mySeft = "Bản thân";
		next = "Tiếp";
		login = "Đăng nhập";
		remem = "Nhớ";
		register = "Đăng ký";
		fogetPass = "Quên mật khẩu";
		nameAcc = "Tên tài khoản";
		FAQs = "Câu hỏi thường gặp";
		updateGame = "Cập nhật game";
		support = "Hỗ trợ";
		delRMS = "Xóa bộ nhớ tạm";
		alreadyDelRMS = "Đã ";
		youUseNumRegGetpass = "Bạn phải dùng số điện thoại đăng ký tài khoản để lấy mật khẩu.";
		areYouUseNumReg = "Có phải bạn đang dùng số điện thoại đăng ký không?";
		removee = "Bỏ";
		viewRule = "điều khoản";
		areYouAgreeRule = "Bạn phải chấp nhận điều khoản.";
		acc = "Tài khoản";
		pass = "Mật khẩu";
		selectRegion = "Chọn thành phố";
		rememPass = "Nhớ mật khẩu";
		eventt = "Sự kiện";
		giveGift = "Tặng quà";
		hit = "Đánh";
		kiss = "Hôn";
		viewInfo = "Thông tin";
		privateMsg = "Nhắn tin";
		action = "Hành động";
		feel = "Cảm xúc";
		exchange = "Giao dịch";
		giveGiftFlower = " tặng hoa rơi cho ";
		with = " với ";
		refused = "Từ chối";
		noQ = " không ?";
		loadCard = new string[2][];
		loadCard[0] = new string[2]
		{
			"Số seri:",
			string.Empty
		};
		loadCard[1] = new string[2]
		{
			"Mã số thẻ:",
			string.Empty
		};
		myIndex = new string[6] { "Lv: ", "T.Thiện", "G.Rối", "S.Điệu", "V.Vẻ", "S.Khỏe" };
		index = "Chỉ số";
		doo = "Mua vật phẩm";
		detail = "Chi tiết";
		have = "Hiện có: ";
		strName = new string[3] { "Nạp tiền", "Chuyển tiền", "Bản thân" };
		strTransMoney = new string[2] { "TK chính sang nông trại", "TK nông trại sang chính" };
		loadMoney = "NẠP TIỀN";
		msgNew = "Tin đến";
		closeTab = "Đóng tab";
		beginChat = "Bắt đầu chat với ";
		success = "Xong";
		createChar = "Tạo nhân vật";
		gender = new string[2] { "Nam", "Nữ" };
		face = "mặt ";
		createCharFail = "Tạo nhân vật không thành công.";
		lvNotChange = "Tiền, cấp không đổi";
		cap = "Cấp:";
		salonBeauty = "Thẩm mỹ viện";
		lvUse = "Cấp độ sử dụng: ";
		cancel = "Hủy";
		canHarvest = "co the thu hoach";
		hasRob = "da bi an trom";
		container = "Rương đồ";
		doYouWantDel = "Bỏ món đồ này ?";
		trasContainter = new string[4] { "Bỏ món đồ này vào giỏ ?", "Sử dụng vật phẩm này ?", "Bỏ vào giỏ đồ ?", "Bỏ vào rương ?" };
		trans = "Di chuyển";
		doBen = "Độ bền: ";
		use = "Sử dụng";
		sentMsg = "Đã gửi tin nhắn.";
		canNotSendMsg = "Không thể gửi tin nhắn.";
		doYouWantExit = "Nếu thoát bạn sẽ bị xử thua. Bạn có muốn thoát?";
		lister = new string[3] { "Nghe nhỏ", "Nghe vừa", "Nghe lớn" };
		cardTypeName = new string[7] { "Cóc", "Sảnh", "Đôi", "Ba lá", "Ba đôi thông", "Bốn đôi thông", "Tứ quý" };
		chatHeo = new string[8] { "Chặt heo đen", "Chặt heo đỏ", "Chặt đôi heo đen", "Chặt đôi heo đỏ", "Chặt đôi heo 1 đen 1 đỏ", "Chặt 3 đôi thông", "Chặt tứ quý", "Chặt 4 đôi thông" };
		info = "Thông tin";
		changePass = "Đổi mật khẩu";
		nameChangePass = new string[3][];
		nameChangePass[0] = new string[2] { "Mật khẩu", "Cũ" };
		nameChangePass[1] = new string[2] { "Mật khẩu", "Mới" };
		nameChangePass[2] = new string[2] { "Nhập lại", "Mật khẩu" };
		finish = "Xong";
		enterPass = new string[5] { "Xin nhập mật khẩu hiện tại.", "Xin nhập mật khẩu mới.", "Xin nhập lại mật khẩu mới.", "Hai mật khẩu mới phải giống nhau.", "Mật khẩu mới phải khác mật khẩu cũ." };
		toss = "Quăng câu";
		bite = "Cắn câu";
		miss = "Trật rồi";
		numberFish = "Số cá câu được: ";
		achieve = "Thành tích";
		view = "Xem ";
		nameReg = new string[4] { "Bạn chưa nhập tên", "Bạn chưa nhập mật khẩu", "Bạn chưa nhập lại mật khẩu.", "Hai mật khẩu không giống nhau." };
		enterAgain = "Nhập lại";
		fallFlower = new string[2] { "Hoa rơi", "Tim bay" };
		doYouWantToTrade = "Bạn có muốn giao dịch không ?";
		giveGame = "Tặng game cho..";
		sentToFriend = "Gui cho ban be";
		phoneNumber = "So dien thoai";
		youCanSelectFromMenu = "Ban co the chon so dien thoai tu Menu / Danh ba";
		otherGame = "Game khác";
		doYouWantUpgradeCoffer = "Bạn có muốn nâng cấp rương không ?";
		doYouWantExitIntoRegion = "Bạn có muốn thoát game để vào mục này không?";
		sendTo = " gửi đến ";
		enterCard = new string[2] { "Bạn chưa nhập số seri.", "Bạn chưa nhập mã số thẻ." };
		day = "ngày";
		theft = "ăn trộm";
		food = "Thức ăn";
		dial = "Quay số";
		doYouWantDial = "Ban có muốn quay số món đồ này không ?";
		forever = "Vĩnh viễn";
		doYouWanBuyPrice = "Bạn muốn mua vật phẩm này với giá";
		sett = "Đặt";
		homeRepait = "Chỉnh sửa nhà";
		buyItem = "Mua đồ";
		latGach = "lát gạch, sơn tường";
		sellItem = "Chuyển, bán đồ";
		noItem = "Không có vật phẩm ở đây";
		move = "Di chuyển";
		rota = "Xoay";
		doWantSellItem = "Bạn có muốn bán?";
		noPlaceItemHere = "Bạn không được đặt ở đây.";
		haveItem = "Đã có vật phẩm";
		setTuong = "Phải đặt sát tường.";
		noFriend = "Không có bạn trong khu này.";
		goHome = "Về nhà";
		joinFrHome = "Vào nhà bạn bè";
		cho = "cho";
		dunation = "tặng";
		inviteMyHouse = "Mời đến nhà";
		upgradeChest = "Nâng cấp rương";
		outHouse = "Bạn bị chủ nhà đuổi.";
		cityIsOffLine = "Thành phố này đang tạm dừng hoạt động, xin đăng nhập thành phố khác hoặc đăng nhập lại sau.";
		chay = "Cháy";
		u = "Ù";
		denU = "Đền ù";
		youAre = "Bạn được ";
		youAreInvite = "Bạn được mời về nhà bởi ";
		doYouWant = "Bạn có muốn không ?";
		basket = "Giỏ đồ";
		canNotConnect = "Không thể kết nối, xin kiểm tra lại GPRS/3G/Wifi.";
		constructing = "Đang xây dựng";
		roomList = "DANH SÁCH PHÒNG";
		roomName = "Tên phòng";
		emptyRoom = "Trống";
		selectLanguage = "Language";
		uNeedExitGame = "Để chọn ngôn ngữ vui lòng khởi động lại game.";
		Dial = "Quay";
		enterPassReferral = "Nhập mã giới thiệu (nếu có).";
		registerSuccess = "Đã gửi thông tin đăng ký. Xin thoát game và chờ giây lát.";
		cannotRegister = "Không thể gởi tin nhắn đăng ký.";
		gettingPrice = "Đang lấy giá ô đất.";
		sms = string.Empty;
		sendSmgFinish = "Đã nạp tiền xong. Xin chờ tin nhắn xác nhận. Lưu ý nạp ít hơn 10 lần trong ngày.";
		notSendSmg = "Không thể gửi tin nhắn. Xin soạn tin: ";
		email = "Nhập email nếu có";
		back = "Quay về";
		startTa = "Bắt đầu tả";
		selectAgain = "Chọn lại";
		ta = "Tả";
		wearing = "Đang mặc";
		levelRequest = "Cấp độ: ";
		gift = "Quà";
		map = "Bản đồ";
		tiengViet = "Tiếng Việt";
		tiengAnh = "English";
		catdo = "Cất đồ";
		removeFriend = "Xóa bạn";
		uRemoveFriend = "Bạn muốn xóa người này ?";
		viewContinue = "Xem tiếp..";
		roomOn = "Phòng";
		enterNumber = "Đến bàn";
		chooseAnotherCity = "Chọn thành phố";
		top = "Xếp hạng";
		quay = "Quay";
		game = "Trò chơi";
		cook = "Nấu ăn";
		cooking = "Đang nấu";
		doUWantCancel = "Bạn có muốn hủy món đang nấu không?";
		notEnough = "Không đủ ";
		salePrice = "Giá bán: ";
		material = "Nguyên liệu: ";
		done = "Hoàn thành";
		QuickCooking = "Nấu nhanh";
		time = "Thời gian: ";
		QuickUpgrade = "Nâng cấp nhanh";
		update = "Nâng cấp";
		harvest = "Thu hoạch";
		doUWantCancel = "Bạn có muốn hủy món đang nấu không?";
		datCuoc = "Đặt cược";
		other = "Khác...";
		usureStop = "Bạn có chắc muốn dừng hướng dẫn không?";
		tkNew = "Tk game: ";
		wedding = "Quan hệ";
		doYouWantTransMoney = "Bạn có chắc muốn chuyển tiền không ?";
		doYouWantAddFr = "Bạn có muốn kết bạn với người này không ?";
		nameTab = new string[2] { "Thông tin", "Bản thân" };
	}

	public string[][] getTextMiniMap()
	{
		return new string[6][]
		{
			new string[4] { "Chào mừng bạn đến với Avatar - Thành phố diệu kỳ", "Chúng ta sẽ dạo một vòng qua thành phố này nhé!", "Thành phố có rất nhiều khu, chúng ta sẽ đến từng khu để tìm hiểu", "Khu Giải Trí là nơi nào nhiệt nhất thành phố. Mời bạn chọn vào nào!" },
			new string[2] { "Nông Trại là nơi trồng trọt và chăn nuôi, bạn có thể tăng thêm thu nhập", "Bạn hãy chọn vào mục Nông Trại nào" },
			new string[2] { "Tiếp theo là khu Mua Sắm, nơi mà bạn có thể lựa chọn cho mình những bộ trang phục đẹp mắt.", "Chọn vào tham quan khu Mua Sắm ngay bạn nhé!" },
			new string[2] { "Tiếp theo là khu Sinh Thái, nơi mà bạn có thể thư giãn với việc câu cá", "Mời bạn chọn vào Khu Sinh Thái" },
			new string[2] { "Khu vực Công Viên là nơi bạn có thể gặp gỡ và trò chuyện với bạn bè", "Bạn có thể vào thử Công Viên. Sau khi dạo một vòng hãy đến Trạm Xe Buýt để trở lại nơi này nhé!" },
			new string[2] { "Thành phố diệu kỳ còn rất nhiều khu khác để bạn khám phá. Hãy ghé qua khu sân bay thường xuyên để cập nhật các địa điểm mới", "Giờ bạn có thể vào nông trại, vào hội cờ, đi mua sắm,đi câu cá, hoặc làm bất kỳ điều gì bạn thích. Cám ơn bạn đã xem hướng dẫn!" }
		};
	}

	public string[][] getTextMapScr()
	{
		return new string[3][]
		{
			new string[2] { "Chào mừng bạn đến khu giải trí.", "Nơi đây gồm hội quán cờ, Tòa thị chính, Trường đua pet sôi động và các gian hàng quay số may mắn cùng với đấu giá ngược." },
			new string[2] { "Đây là tòa thị chính, nơi bạn có thể nhận những nhiệm vụ trong game và xin gia nhập vào các hội nhóm.", "Hãy di chuyển nhân vật đến tham quan tòa thị chính đi nào!" },
			new string[2] { "Đây là trường đua thú sôi động. Bạn có thể vào xem những trận đua thú vô cùng hấp dẫn.", "Hãy tham quan trường đua trước khi chúng ta di chuyển sang khu vực khác nhé!" }
		};
	}

	public string[][] getTextMuaSam()
	{
		return new string[3][]
		{
			new string[2] { "Chào mừng bạn đến khu mua sắm, tại đây bạn có thể thỏa thích lựa chọn cho mình những bộ thời trang đẹp mắt và cá tính.", "Đầu tiên mời bạn vào Shop tham quan. Hãy di chuyển nhân vật đến shop nào." },
			new string[2] { "Đây là nhà bán thú nuôi, nơi bạn có thể lựa chọn cho mình những chú pet thật xinh xắn.", "Hãy vào xem một chút nhé!" },
			new string[2] { "Bạn có thể vào thay đổi kiểu tóc và mắt của mình tại Thẩm Mỹ Viện.", "Hãy vào tham quan thử nhé!" }
		};
	}

	public string[][] getTextToaThiChinh()
	{
		return new string[1][] { new string[1] { "Hãy gặp thị trưởng để nhận nhiệm vụ và gặp NPC Hội Nhóm để xin gia nhập vào các hội nhóm." } };
	}

	public string[][] getTextFarmPath()
	{
		return new string[4][]
		{
			new string[3] { "Khu vực nông trại có 4 nơi bạn có thể vào: Cửa hàng, ATM, Nông trại của mình, và Nông trại của bạn bè.", "Cửa hàng là nơi bạn mua hạt giống, vật nuôi và các vật phẩm khác", "Tại sao bạn lại không thử mua một ít hạt giống nhỉ?" },
			new string[2] { "Hiện tại trong người của bạn có sẵn vài hạt giống. Nhưng bạn vẫn có thể mua thêm hạt giống khác nếu thích.", "Hãy chọn mua thử nào!" },
			new string[2] { "Hãy chọn số lượng muốn mua", "Sau khi mua xong, bạn hãy chọn Đóng để rời khỏi cửa hàng" },
			new string[2] { "Chúng ta đã có một số hạt giống rồi!", "Hãy bước vào khu vực nông trại của bạn để bắt đầu gieo hạt!" }
		};
	}

	public string[][] getTextFarm()
	{
		return new string[7][]
		{
			new string[6] { "Đây là nông trại của bạn", "Chúng ta sẽ bắt đầu trải nghiệm làm một người nông dân chăm chỉ nhé!", "Bạn có thấy những ô đất không?", "Đây là khu vực bạn có thể trồng cây.", "Bắt đầu thôi nào! Bạn hãy di chuyển đến đó và chọn một ô đất", "Hãy chọn mục Làm Đất để xới đất nào!" },
			new string[2] { "Chúc mừng! Bạn đã hoàn thành xong việc làm đất", "Tiếp theo bạn hãy chọn hạt giống." },
			new string[2] { "Bạn đã gieo hạt. Trên mỗi ô đất có hiển thị thời gian bạn có thể thu hoạch được", "Bạn hãy thường xuyên vào tưới nước, bón phân cho cây cho đến khi thu hoạch nhé!" },
			new string[3] { "Đây là khu chăn nuôi gia súc.", "Bạn cần mua gia súc ngoài cửa hàng và thả nó vào đây", "hãy chăm sóc nó, cho ăn và tiêm thuốc bổ đều đặn, đến khi lớn bạn có thể thu hoạch sữa và trứng" },
			new string[1] { "Đây là nhà bếp, nơi bạn có thể nấu những món ăn từ nông sản bạn thu hoạch được." },
			new string[2] { "Đây là cây khế, cây khế sẽ cho thu hoạch trong thời gian nhất định.", "Hãy nâng cấp cây khế lên càng cao, sản lượng thu hoạch sẽ càng nhiều bạn nhé!" },
			new string[3] { "Bạn có thể nuôi cá trong ao này bằng cách mua cá từ cửa hàng bên ngoài", "Sau khi thu hoạch cây, vật nuôi, bạn sẽ có một khoản tiền nhỏ trong tài khoản nông trại", "Bạn có thể ra ATM để chuyển sang tài khoản chính để có thể dùng nhé!" }
		};
	}

	public string[][] getTextShop()
	{
		return new string[2][]
		{
			new string[2] { "Chào mừng bạn đến với cửa hàng quần áo.", "Hãy bước đến gặp người bán hàng để thử quần áo, bạn nhớ chú ý giá cả nhé!" },
			new string[2] { "Sử dụng các mũi tên để chọn các bộ quần áo khác nhau", "Nếu bạn có đủ tiền, hãy chọn mua một bộ quần áo mới" }
		};
	}

	public string[][] getTextFish()
	{
		return new string[8][]
		{
			new string[2] { "Chào mừng bạn đến với khu câu cá.", "Có 3 khu câu cá khác nhau, với 3 cấp độ khác nhau" },
			new string[1] { "Khu câu cá rô dành cho người mới tập câu" },
			new string[1] { "Khu câu cá lóc dành cho các bạn đã biết câu" },
			new string[1] { "Khu câu cá mập dành cho các bạn đã là cao thủ câu cá" },
			new string[1] { "Để có thể câu cá bạn phải mua cần câu, mồi câu, vé câu" },
			new string[1] { "Để có thể mua bạn có thể chat chữ cauca cửa hàng sẽ tự động hiện lên" },
			new string[1] { "Hoặc chat chữ banca nếu bạn muốn bán cá" },
			new string[1] { "Giờ chúng ta sẽ rời nơi này. Bạn có thể đến đây bất cứ khi nào bạn muốn!" }
		};
	}

	public string[] getTextOut()
	{
		return new string[1] { "Bạn có thể ra khỏi nơi này bằng cách đi đến nơi mũi tên chỉ" };
	}

	public static string[][][] getNameServer()
	{
		string[][][] array = new string[2][][]
		{
			new string[2][],
			new string[1][]
		};
		array[0][0] = new string[4] { "Xứ Sở Diệu Kỳ", "Thành Phố Hoàn Mỹ", "Thành Phố Tri Kỷ", "Thành Phố Diệu Kỳ" };
		array[0][1] = new string[2] { "Xứ Sở Thần Tiên", "Thành Phố Bảo Bình" };
		array[1][0] = new string[2] { "International Server", "Aries City" };
		return array;
	}

	public static string getPath()
	{
		return hd[Canvas.stypeInt];
	}

	public static string getMoney()
	{
		if (MapScr.isNewVersion)
		{
			return "xeng";
		}
		return dola;
	}

	public static string getMoneyH()
	{
		if (MapScr.isNewVersion)
		{
			return "xèng";
		}
		return dola;
	}
}
