public class Tile
{
	public string name;

	public int priceXu;

	public int priceLuong;
}
